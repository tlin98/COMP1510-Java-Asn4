Tony Lin, A00984756, 1E, December 7 2016

This assignment is 100% complete.


------------------------
Question one (Statistics) status:

Complete.

------------------------
Question two (DrawTriangle) status:

Complete. I wish we were taught how to use Java.util.Timer using threads.

------------------------
Question three (StopWatch) status:

Complete.
